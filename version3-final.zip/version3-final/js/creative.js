(function($) {
    "use strict"; // Start of use strict

    // Smooth scrolling using jQuery easing
    $('a.js-scroll-trigger[href*="#"]:not([href="#"])').click(function() {
        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
                $('html, body').animate({
                    scrollTop: (target.offset().top)
                }, 1000, "easeInOutExpo");
                return false;
            }
        }
    });

    // Closes responsive menu when a scroll trigger link is clicked
    $('.js-scroll-trigger').click(function() {
        $('.navbar-collapse').collapse('hide');
    });





    // Scroll reveal calls
    window.sr = ScrollReveal();
    sr.reveal('.property-card', {
        duration: 600,
        scale: 0.3,
        distance: '0px'
    }, 200);

    sr.reveal('.marketing-card', {
        duration: 600,
        scale: 0.3,
        distance: '0px'
    }, 200);


    sr.reveal('.buyers', {
        duration: 600,
        scale: 0.3,
        distance: '0px'
    }, 200);

    sr.reveal('.auction', {
        duration: 600,
        delay: 200
    });
    
    sr.reveal('.team', {
        duration: 600,
        delay: 200
    });

    sr.reveal('.timeline-panel', {
        duration: 600,
        delay: 200
    });

    sr.reveal('.methods', {
        duration: 600,
        scale: 0.3,
        distance: '0px'
    }, 200);

    sr.reveal('.campaign', {
        duration: 600,
        delay: 200
    });

    //
    //  sr.reveal('#schedule .panel', {
    //    duration: 1000,
    //    delay: 200
    //  });
    //
    //  sr.reveal('.marketing-total', {
    //    duration: 1200,
    //    scale: 0.3,
    //    distance: '0px'
    //  }, 300);
    //
    //  sr.reveal('.collateral-list li', {
    //    duration: 1200,
    //    scale: 0.3,
    //    distance: '0px'
    //  }, 500);




})(jQuery); // End of use strict


// Set all carousel items to the same height
function carouselNormalization() {

    window.heights = [], //create empty array to store height values
        window.tallest; //create variable to make note of the tallest slide

    function normalizeHeights() {
        jQuery('#carousel-mid .item').each(function() { //add heights to array
            window.heights.push(jQuery(this).outerHeight());
        });
        window.tallest = Math.max.apply(null, window.heights); //cache largest value
        jQuery('#carousel-mid .item').each(function() {
            jQuery(this).css('min-height',tallest + 'px');
        });
    }
    normalizeHeights();

    jQuery(window).on('resize orientationchange', function () {

        window.tallest = 0, window.heights.length = 0; //reset vars
        jQuery('#carousel-mid .item').each(function() {
            jQuery(this).css('min-height','0'); //reset min-height
        });

        normalizeHeights(); //run it again

    });

}


function carouselNormalization2() {

    window.heights = [], //create empty array to store height values
        window.tallest; //create variable to make note of the tallest slide

    function normalizeHeights() {
        jQuery('#carousel-mid2 .item').each(function() { //add heights to array
            window.heights.push(jQuery(this).outerHeight());
        });
        window.tallest = Math.max.apply(null, window.heights); //cache largest value
        jQuery('#carousel-mid2 .item').each(function() {
            jQuery(this).css('min-height',tallest + 'px');
        });
    }
    normalizeHeights();

    jQuery(window).on('resize orientationchange', function () {

        window.tallest = 0, window.heights.length = 0; //reset vars
        jQuery('#carousel-mid2 .item').each(function() {
            jQuery(this).css('min-height','0'); //reset min-height
        });

        normalizeHeights(); //run it again

    });



}
